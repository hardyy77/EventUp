package com.example.eventup.workers

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.eventup.utils.FirestoreUtils

class UpdateInterestingEventsWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {

    override fun doWork(): Result {
        Log.d("UpdateInterestingEventsWorker", "Worker started")
        FirestoreUtils.updateInterestingEvents(
            onSuccess = {
                Log.d("UpdateInterestingEventsWorker", "Successfully updated interesting events")
                Result.success()
            },
            onFailure = { e ->
                Log.e("UpdateInterestingEventsWorker", "Failed to update interesting events", e)
                Result.failure()
            }
        )
        return Result.success()
    }
}
