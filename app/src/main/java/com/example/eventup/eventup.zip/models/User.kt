package com.example.eventup.models

import com.google.firebase.firestore.PropertyName

data class User(
    var id: String = "",
    val email: String = "",
    val displayName: String = "",
    @get:PropertyName("role") @set:PropertyName("role") var role: String = "user"
)
