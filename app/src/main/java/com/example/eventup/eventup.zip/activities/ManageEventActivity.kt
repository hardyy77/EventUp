package com.example.eventup.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.eventup.R
import com.example.eventup.models.Event
import com.example.eventup.utils.FirestoreUtils
import com.google.firebase.firestore.FirebaseFirestore

class ManageEventActivity : AppCompatActivity() {

    private lateinit var titleField: EditText
    private lateinit var dateField: EditText
    private lateinit var locationField: EditText
    private lateinit var genresField: EditText
    private lateinit var descriptionField: EditText
    private lateinit var saveButton: Button
    private lateinit var deleteButton: Button

    private lateinit var db: FirebaseFirestore
    private var eventId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_event)

        db = FirebaseFirestore.getInstance()

        titleField = findViewById(R.id.titleField)
        dateField = findViewById(R.id.dateField)
        locationField = findViewById(R.id.locationField)
        genresField = findViewById(R.id.genresField)
        descriptionField = findViewById(R.id.descriptionField)
        saveButton = findViewById(R.id.saveButton)
        deleteButton = findViewById(R.id.deleteButton)

        eventId = intent.getStringExtra("EVENT_ID")

        if (eventId != null) {
            loadEvent(eventId!!)
            deleteButton.visibility = View.VISIBLE
        } else {
            deleteButton.visibility = View.GONE
        }

        saveButton.setOnClickListener {
            saveEvent()
        }

        deleteButton.setOnClickListener {
            deleteEvent()
        }
    }

    private fun loadEvent(eventId: String) {
        db.collection("events").document(eventId).get()
            .addOnSuccessListener { document ->
                if (document != null) {
                    val event = document.toObject(Event::class.java)
                    if (event != null) {
                        titleField.setText(event.name)
                        dateField.setText(event.date)
                        locationField.setText(event.location)
                        genresField.setText(event.genres)
                        descriptionField.setText(event.description)
                    }
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to load event", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveEvent() {
        val title = titleField.text.toString()
        val date = dateField.text.toString()
        val location = locationField.text.toString()
        val genres = genresField.text.toString()
        val description = descriptionField.text.toString()

        if (title.isEmpty() || date.isEmpty() || location.isEmpty() || genres.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val event = Event(eventId ?: db.collection("events").document().id, title, date, location, genres, description)

        FirestoreUtils.saveEvent(event,
            onSuccess = { _ ->
                Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show()
                sendRefreshBroadcast()
                finish()
            },
            onFailure = {
                Toast.makeText(this, "Failed to save event", Toast.LENGTH_SHORT).show()
            })
    }

    private fun deleteEvent() {
        eventId?.let {
            FirestoreUtils.deleteEvent(it,
                onSuccess = {
                    Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show()
                    sendRefreshBroadcast()
                    finish()
                },
                onFailure = {
                    Toast.makeText(this, "Failed to delete event", Toast.LENGTH_SHORT).show()
                })
        }
    }

    private fun sendRefreshBroadcast() {
        val intent = Intent("com.example.eventup.REFRESH_EVENTS")
        sendBroadcast(intent)
    }
}
