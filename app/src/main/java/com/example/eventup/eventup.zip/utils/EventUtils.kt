package com.example.eventup.utils

import android.content.Context
import com.example.eventup.models.Event
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*

object EventUtils {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())


    fun getPopularEvents(callback: (List<Event>) -> Unit) {
        val firestore = FirebaseFirestore.getInstance()
        val currentDate = dateFormat.format(Date())
        firestore.collection("events")
            .whereGreaterThanOrEqualTo("date", currentDate)
            .orderBy("date")
            .orderBy("interest", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(4)
            .get()
            .addOnSuccessListener { result ->
                val events = result.map { document ->
                    val event = Event(
                        id = document.id,
                        name = document.getString("name") ?: "",
                        location = document.getString("location") ?: "",
                        date = document.getString("date") ?: "",
                        genres = document.getString("genres") ?: "",
                        description = document.getString("description") ?: "",
                        interest = document.getLong("interest")?.toInt() ?: 0,
                        isFavorite = document.getBoolean("isFavorite") ?: false
                    )
                    println("Fetched popular event with ID: ${event.id}")
                    event
                }
                callback(events)
            }
            .addOnFailureListener { exception ->
                println("Error getting popular events: $exception")
            }
    }

    fun getAllEvents(callback: (List<Event>) -> Unit) {
        val firestore = FirebaseFirestore.getInstance()
        firestore.collection("events")
            .get()
            .addOnSuccessListener { result ->
                val events = result.map { document ->
                    val event = Event(
                        id = document.id,
                        name = document.getString("name") ?: "",
                        location = document.getString("location") ?: "",
                        date = document.getString("date") ?: "",
                        genres = document.getString("genres") ?: "",
                        description = document.getString("description") ?: "",
                        interest = document.getLong("interest")?.toInt() ?: 0,
                        isFavorite = document.getBoolean("isFavorite") ?: false
                    )
                    println("Fetched event with ID: ${event.id}")
                    event
                }
                callback(events)
            }
            .addOnFailureListener { exception ->
                println("Error getting events: $exception")
            }
    }

    fun filterEvents(events: List<Event>, query: String): List<Event> {
        return events.filter { event ->
            event.name.contains(query, ignoreCase = true) ||
                    event.location.contains(query, ignoreCase = true) ||
                    event.date.contains(query, ignoreCase = true) ||
                    event.genres.contains(query, ignoreCase = true) ||
                    event.description.contains(query, ignoreCase = true)
        }
    }
}
